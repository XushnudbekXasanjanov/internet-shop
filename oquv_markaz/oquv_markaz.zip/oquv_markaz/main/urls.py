from django.urls import path
from .views import *
from .main import *

urlpatterns = [
    path('filterteacherss/', TeachersFilter.as_view()),
    path('create-course/',CreateCourse.as_view()),
    path('create-student/',CreateStudent.as_view()),
    path('view-students/',ViewStudents.as_view()),
    path('paymentstudent/',Payment.as_view()),
    path('attendence-student/',AttendanceStudents.as_view()), # ishlamayabdi
    path('rate-student/',RateStudents.as_view()), #ishlamayabdi
    path('complaints/',ComplaintParents.as_view()),
    path('view-complaints/',ViewComplaints.as_view()),
    path('create-userjob/',CreateRequests.as_view()),
    path('register/', Register),
    path('Login/', Login)
]