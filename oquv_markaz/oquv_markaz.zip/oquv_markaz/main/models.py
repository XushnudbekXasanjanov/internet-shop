from django.db import models
from django.contrib.auth.models import AbstractUser


class DirectionTeachers(models.Model):
    name = models.CharField(max_length=255)

    def __str__(self):
        return self.name

class User(AbstractUser):
    STATUS = (
        (1, 'director'),
        (2, 'oqituvchi'),
        (3, 'oquvchi'),
        (4, 'manager'),
        (5, 'ota-ona'),
        (6, 'user')
    )
    types = models.IntegerField(choices=STATUS,default=6)
    category = models.ForeignKey(DirectionTeachers,on_delete=models.CASCADE,null=True,blank=True)
    phone = models.IntegerField(null=True,blank=True)


class CategoryDirections(models.Model):
    name = models.CharField(max_length=255)
    duration = models.IntegerField()
    monthly_payment = models.FloatField()
    hour = models.FloatField()
    days = models.CharField(max_length=255)

class Student(models.Model):
    fullname = models.CharField(max_length=255)
    direction = models.ForeignKey(CategoryDirections, on_delete=models.CASCADE)
    age = models.IntegerField()
    phone = models.IntegerField()
    adress = models.CharField(max_length=255)
    kod = models.IntegerField(unique=True)
    img = models.ImageField(upload_to='students/')


class Course(models.Model):
    students = models.ManyToManyField(Student)
    have_place = models.BooleanField()


class Lessons(models.Model):
    course = models.ForeignKey(Course,on_delete=models.CASCADE)
    name = models.CharField(max_length=255)
    date = models.DateField()


class Rate(models.Model):
    student = models.ManyToManyField(Lessons)
    rate = models.IntegerField()


class Attendance(models.Model):
    lesson = models.ForeignKey(Lessons,on_delete=models.CASCADE)
    user = models.ForeignKey(Course,on_delete=models.CASCADE)
    keldi_ketdi = models.BooleanField()


class PaymentStudent(models.Model):
    course = models.ForeignKey(Student, on_delete=models.CASCADE)
    summa = models.FloatField()
    is_paid = models.BooleanField(default=False)
    date = models.DateTimeField()



class RequestUserToJob(models.Model):
    STATUS = (
        (1,'teacher'),
        (2,'student'),
        (3,'Manager')
    )
    category = models.IntegerField(choices=STATUS)
    name = models.CharField(max_length=255)
    age = models.IntegerField()
    email = models.EmailField()
    adress = models.CharField(max_length=255)
    phone = models.IntegerField()


class Complaint(models.Model):
    STATUS = (
        (1, 'Teacher'),
        (2, 'School')
    )
    types = models.IntegerField(choices=STATUS)
    name = models.CharField(max_length=255)
    phone = models.IntegerField()
    subject = models.TextField()
    adress = models.CharField(max_length=255)



#
# 6ta user bolad
# direktor
# oqituvchi
# oquvchi
# manager
# user
# ota-ona
#
# direktor - O'qituvchilarni qaysi yo'nalish bo'yicha hammaasini chiqarib berishi kere,zaprosni qabul qilishi kere userdan.yangi o'quv kursi qo'sha olishi kere. o'qituvchi manager va o'quvchilarni o'chira olishi kere.
# oqituvchi - kurs yaratoledi,kursga oquvchilarni qoshovledi.Yaratilgan kursga darsliklardi yukloledi.Davomati bo'ladi(keldi kelmadi tolov,baholash).Har bir oqituvchi ish planini koroledi.delete qilishi kerak.O'quvchilar ro'yhati.
# reception - o'quvchini kurslarga yozadi va kategoriya chiqadi va qo'shadi.Tolovni u ham boshqarishi kerak.delete qilishi kere o'quvchilarni.Darslar ro'yhati tuzishi kerak.O'quvchini update qilishi kerak.Savol-javob qilishi kerak(test).
# oquvchi - Darsliklardi kora olishi kere.davomatini faqat kora olishi kere.Darslik jadvaldi kora olishi kere.Full register qila olishi kere.Boshqa kurslarga zapros tasha olishi kere.Jalba yozishi kere,ism familya nomerini kiritgan xolda.O'qituvchini baxolasin anonim tarzda va direktor va menejerga korinsin
# user - register qila olishi kere o'qtuvchilikka,oquvchilikka yoki receptionlikka zapros tasha olishi kere.
# ota-ona - oglini baholarini kora olishi kere.Davomatini kora olishi kere.ota ona oglini darsga kela olmasligizni yoza olish kere.

#
# Student create qiladigan Funksiya ///////////////
# Oddiy userga CategoryForUser dagi objectlarni koradigan funksiya
# Complaint ya'ni ota onani shikoyatini yoki oquvchini create qiluvchi funksiya va bu shikoyatlarni faqat direktor yoki reception kora olishi kerak' //////////////
# User Zapros tashay oladigan funksiya RequestUser bu osha model
# Direktor o'zi ham qo'sha olishi kerak ishchi yoki o'quvchi'
# faqat o'quvchi dars jadvalini ko'ra olishi kerak

