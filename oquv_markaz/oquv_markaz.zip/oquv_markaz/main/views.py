from rest_framework.response import Response
from rest_framework import authentication, permissions
from .serializer import *
from rest_framework.views import APIView
from rest_framework.decorators import api_view
import random
import string
import datetime
from django.contrib.auth import login, logout, authenticate
from rest_framework.authtoken.models import Token
