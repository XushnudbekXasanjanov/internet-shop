from rest_framework.response import Response
from rest_framework import authentication, permissions
from .serializer import *
from rest_framework.views import APIView
from rest_framework.decorators import api_view
import random
import string
import datetime
from django.contrib.auth import login, logout, authenticate
from rest_framework.authtoken.models import Token

class TeachersFilter(APIView):
    authentication_classes = [authentication.TokenAuthentication]
    permission_classes = [permissions.IsAuthenticated]

    def get(self,request):
        user = request.user
        if user.types == 1:
            query = User.objects.filter(types=2)
            ser = UserSerializer(query,many=True)
            return Response(ser.data)
        else:
            return Response('xatolik')



class CreateStudent(APIView):
    authentication_classes = [authentication.TokenAuthentication]
    permission_classes = [permissions.IsAuthenticated]

    def post(self,request):
        user = request.user
        if user.types == 4 or user.types == 1:
            fullname = request.POST.get('fullname')
            direction = request.POST.get('direction')
            age = request.POST.get('age')
            phone = request.POST.get('phone')
            adress = request.POST.get('adress')
            img = request.POST.get('img')
            unik = string.digits
            kod = ''.join((random.choice(unik) for i in range(4)))
            query = Student.objects.create(fullname=fullname,direction_id=direction,age=age,phone=phone,adress=adress,kod=kod,img=img)
            ser = StudentSerializer(query)
            return Response(ser.data)




class Payment(APIView):
    authentication_classes = [authentication.TokenAuthentication]
    permission_classes = [permissions.IsAuthenticated]

    def post(self, request):
        user = request.user
        if user.types == 3:
            course = request.POST.get('course')
            summa = request.POST.get('summa')
            kod = request.POST.get('kod')
            for i in Student.objects.all():
                if i.kod == int(kod):
                     query = PaymentStudent.objects.create(is_paid=True, summa=float(summa), course_id=course,date=datetime.datetime.now())
                     ser = PaymentSerializer(query)
                     data = {
                         'Tolandi': ser.data,
                     }
                     return Response(data)
                else:
                    return Response('error')



class AttendanceStudents(APIView):
    authentication_classes = [authentication.TokenAuthentication]
    permission_classes = [permissions.IsAuthenticated]

    def post(self,request):
        user = request.user
        if user.types == 2 or user.types == 4:
            lesson = request.POST.get('lesson')
            userlar = request.POST.get('userlar')
            keldi_ketdi = request.POST.get('keldi_ketdi')
            query = Attendance.objects.create(lesson=lesson,user=userlar,keld_ketdi=keldi_ketdi)
            ser = AttendanceSerializer(query)
            return Response(ser.data)

class RateStudents(APIView):
    authentication_classes = [authentication.TokenAuthentication]
    permission_classes = [permissions.IsAuthenticated]

    def post(self,request):
        user = request.user
        if user.types == 2:
            student = request.POST.getlist('student')
            rate = request.POST.get('rate')
            query = Rate.objects.create(student=student,rate=rate)
            ser = RateSerializer(query)
            return Response(ser.data)

class ComplaintParents(APIView):
    authentication_classes = [authentication.TokenAuthentication]
    permission_classes = [permissions.IsAuthenticated]

    def post(self,request):
        user = request.user
        if user.types == 5:
            types = request.POST.get('types')
            name = request.POST.get('name')
            phone = request.POST.get('phone')
            subject = request.POST.get('subject')
            adress = request.POST.get('adress')
            query = Complaint.objects.create(types=types,name=name,phone=phone,subject=subject,adress=adress)
            ser = ComplaintSerializer(query)
            print('minasa abdulbosit aytdi')
            return Response(ser.data)



@api_view(["POST"])
def Register(request):
    try:
        username = request.data["username"]
        password = request.data["password"]
        users = User.objects.create(username=username, password=password)
        token = Token.objects.create(user=users)
        login(request, users)
        return Response({"username": username, "user": users.id, "token": token.key})
    except Exception as err:
        return Response({"error": f"{err}"})



@api_view(["POST"])
def Login(request):
    try:
        username = request.data["username"]
        password = request.data["password"]
        try:
            users = User.objects.get(username=username)
            if users is not None:
                usr = authenticate(username=username, password=password)
                if usr is not None:
                    login(request, usr)
                    token, created  = Token.objects.get_or_create(user=users)
                    data = {
                        "username": username,
                        "user_id": users.id,
                        "token": token.key
                    }
                else:
                    status = 403
                    message = "Password error"
                    data = {
                        "status": status,
                        "message": message
                    }
            else:
                status = 403
                message = "Username error"
                data = {
                    "status": status,
                    "message": message
                }
        except:
            status = 404
            message = "Bunday foydalanuvchi mavjud emas!"
            data = {
                "status": status,
                "message": message
            }
        return Response(data)
    except Exception as err:
        return Response({"error": f'{err}'})
